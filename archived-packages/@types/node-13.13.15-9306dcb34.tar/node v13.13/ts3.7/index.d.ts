// NOTE: These definitions support NodeJS and TypeScript 3.7.
// This isn't strictly needed since 3.7 has the assert module, but this way we're consistent.
// Typically type modificatons should be made in base.d.ts instead of here

/// <reference path="base.d.ts" />
