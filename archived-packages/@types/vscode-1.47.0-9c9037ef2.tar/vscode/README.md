# Installation
> `npm install --save @types/vscode`

# Summary
This package contains type definitions for Visual Studio Code (https://github.com/microsoft/vscode).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/vscode.

### Additional Details
 * Last updated: Fri, 10 Jul 2020 02:06:58 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Visual Studio Code Team, and Microsoft](https://github.com/Microsoft).
