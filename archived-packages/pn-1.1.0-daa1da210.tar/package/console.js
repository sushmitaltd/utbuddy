var console = require("console");
module.exports = console;